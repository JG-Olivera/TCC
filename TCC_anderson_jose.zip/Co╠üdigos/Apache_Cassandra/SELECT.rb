require 'cassandra'       # Biblioteca para interagir com Apache Cassandra
require 'benchmark'       # Biblioteca para medir o tempo de execução de código
require 'thread'          # Biblioteca para trabalhar com threads

# Configuração de parâmetros
cluster = Cassandra.cluster(hosts: ['127.0.0.1'])  # Conexão com o cluster Cassandra
session = cluster.connect('guardar_tempo')         # Seleciona o keyspace
tabela = 'modelo_simples'                          # Nome da tabela que será acessada
num_threads = 1                                    # Número de threads que serão criadas (ajustável)
limite_registros = 100                             # Limite de registros a serem selecionados da tabela

# Variável para armazenar o tempo total de execução
tempo_total = 0.0  # Inicializa como 0.0
mutex = Mutex.new   # Mutex para proteger o acesso a tempo_total

# Método para realizar a consulta
def realizar_consulta(session, tabela, limite_registros)
  Benchmark.realtime do
    # Realiza a consulta na tabela, limitando o número de registros retornados
    session.execute("SELECT * FROM #{tabela} LIMIT #{limite_registros}").to_a
  end
end

# Criar um array para armazenar as threads
threads = []

# Criar e iniciar as threads
num_threads.times do
  threads << Thread.new do
    tempo_execucao = 0

    begin
      # Repetir 10 vezes a operação de SELECT
      10.times do
        tempo_execucao += realizar_consulta(session, tabela, limite_registros)
      end

      # Adiciona o tempo de execução ao tempo total de forma segura
      mutex.synchronize { tempo_total += tempo_execucao }
    rescue => e
      puts "Erro ao realizar consulta: #{e.message}"  # Log de erro
    end
  end
end

# Esperar que todas as threads terminem sua execução
threads.each(&:join)

# Calcula o tempo médio por thread, caso num_threads seja maior que 1
tempo_medio = tempo_total / num_threads if num_threads > 1

# Mostrar resultados do tempo total e médio de execução
puts "Tempo total de execução para SELECT: #{tempo_total.round(4)} segundos"
puts "Tempo médio de execução por thread: #{tempo_medio.round(4)} segundos" if num_threads > 1

# Fechar a conexão com o cluster
cluster.close
