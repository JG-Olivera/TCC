require 'csv'
require 'faker'

# Configuração
num_registros = 500_000
arquivo_csv = 'dados04.csv'

# Criar o arquivo CSV e gerar os dados
CSV.open(arquivo_csv, 'w') do |csv|
  # Adicionar o cabeçalho
  csv << ['campo01', 'campo02', 'campo03', 'campo04', 'campo05']

  num_registros.times do
    campo01 = Faker::Name.name  # Gerar um nome aleatório
    campo02 = Faker::Address.city  # Gerar uma cidade aleatória
    campo03 = rand(1..100)  # Gerar um inteiro aleatório entre 1 e 100
    campo04 = rand(1..100)  # Gerar um inteiro aleatório entre 1 e 100
    campo05 = [true, false].sample  # Gerar um boolean aleatório

    # Adicionar os dados à linha do CSV
    csv << [campo01, campo02, campo03, campo04, campo05]
  end
end

puts "Arquivo CSV '#{arquivo_csv}' gerado com sucesso com #{num_registros} registros."
