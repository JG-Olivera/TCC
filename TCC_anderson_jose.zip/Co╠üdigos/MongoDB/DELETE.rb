require 'mongo'
require 'benchmark'
require 'thread'

# Configuração de parâmetros
cliente = Mongo::Client.new(['127.0.0.1:27017'], database: 'Guardar_tempo')
nome_colecao = 'Modelo_simples'
num_threads = 1                   # Número de threads que serão criadas (ajustável)
quantidade_deletes = 100          # Quantidade de documentos a serem deletados

# Variável para armazenar o tempo total de execução
tempo_total = 0.0
mutex = Mutex.new

# Método para realizar o delete
def realizar_delete(colecao, quantidade_deletes)
  Benchmark.realtime do
    # Seleciona e deleta os primeiros registros com base no número desejado
    registros_para_deletar = colecao.find.limit(quantidade_deletes).to_a
    registros_para_deletar.each do |registro|
      colecao.delete_one({ _id: registro['_id'] })
    end
  end
end

# Criar um array para armazenar as threads
threads = []

# Criar e iniciar as threads
num_threads.times do
  threads << Thread.new do
    colecao = cliente[nome_colecao]
    tempo_execucao = 0

    begin
      # Repetir 10 vezes a operação de delete
      10.times do
        tempo_execucao += realizar_delete(colecao, quantidade_deletes)
      end

      # Adiciona o tempo de execução ao tempo total de forma segura
      mutex.synchronize { tempo_total += tempo_execucao }
    rescue => e
      puts "Erro ao realizar delete: #{e.message}"
    end
  end
end

# Esperar que todas as threads terminem sua execução
threads.each(&:join)

# Calcula o tempo médio por thread, caso num_threads seja maior que 1
tempo_medio = tempo_total / num_threads if num_threads > 1

# Mostrar resultados do tempo total e médio de execução
puts "Tempo total de execução para DELETE: #{tempo_total.round(4)} segundos"
puts "Tempo médio de execução por thread: #{tempo_medio.round(4)} segundos" if num_threads > 1

cliente.close
