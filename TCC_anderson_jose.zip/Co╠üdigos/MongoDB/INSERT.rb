require 'mongo'
require 'benchmark'
require 'thread'

# Configuração de parâmetros
cliente = Mongo::Client.new(['127.0.0.1:27017'], database: 'Guardar_tempo')
nome_colecao = 'Modelo_simples'
num_threads = 1                  # Número de threads que serão criadas (ajustável)
quantidade_inserts = 100         # Quantidade de documentos a serem inseridos

# Variável para armazenar o tempo total de execução
tempo_total = 0.0
mutex = Mutex.new

# Método para realizar o insert
def realizar_insert(colecao, quantidade_inserts)
  Benchmark.realtime do
    # Insere múltiplos documentos na coleção
    quantidade_inserts.times do |i|
      colecao.insert_one({
        nome: "Pessoa #{i}",
        cidade: "Cidade #{i % 10}",
        idade: rand(18..65),
        numero: rand(1..100),
        boolean1: [true, false].sample,
        boolean2: [true, false].sample
      })
    end
  end
end

# Criar um array para armazenar as threads
threads = []

# Criar e iniciar as threads
num_threads.times do
  threads << Thread.new do
    colecao = cliente[nome_colecao]
    tempo_execucao = 0

    begin
      # Repetir 10 vezes a operação de insert
      10.times do
        tempo_execucao += realizar_insert(colecao, quantidade_inserts)
      end

      # Adiciona o tempo de execução ao tempo total de forma segura
      mutex.synchronize { tempo_total += tempo_execucao }
    rescue => e
      puts "Erro ao realizar insert: #{e.message}"
    end
  end
end

# Esperar que todas as threads terminem sua execução
threads.each(&:join)

# Calcula o tempo médio por thread, caso num_threads seja maior que 1
tempo_medio = tempo_total / num_threads if num_threads > 1

# Mostrar resultados do tempo total e médio de execução
puts "Tempo total de execução para INSERT: #{tempo_total.round(4)} segundos"
puts "Tempo médio de execução por thread: #{tempo_medio.round(4)} segundos" if num_threads > 1

cliente.close
